<?php


session_start();
$Name=$Mobile=$Email=$PWD=$Address="";
include('assets/Database/DBMySql.php'); $db=new DBMySql;
include('assets/phpscript/FormatedOutput.php');


?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Smart Parking</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,700">
    <link rel="stylesheet" href="assets/fonts/simple-line-icons.min.css">
    <link rel="stylesheet" href="assets/css/Animated-numbers-section.css">
    <link rel="stylesheet" href="assets/css/Feature-Section-MD.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="font-family: Roboto, sans-serif;">
    
    <?php include ("menu.php");?>
    <section class="shadow-lg wrapper-numbers" style="height: 789px;">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2 header-numbers">
                    <h1>Smart Parking System</h1>
                    <p>Book you parking Slot anytime anywhere</p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 offset-md-2 header-numbers">
                    <a class="btn btn-success btn-lg text-white" href="search.php">Book Now</a></div>
            </div>
            <div class="row countup text-center">
                <div class="col-sm-6 col-md-3 column">
                    <p><i class="icon-location-pin" aria-hidden="true"></i></p>
                    <p> <span class="count">50</span></p>
                    <h2>Parkings</h2>
                </div>
                <div class="col-sm-6 col-md-3 column">
                    <p><i class="icon-direction" aria-hidden="true"></i></p>
                    <p> <span class="count replay">500</span></p>
                    <h2>Slots</h2>
                </div>
                <div class="col-sm-6 col-md-3 column">
                    <p><i class="icon-user-following" aria-hidden="true"></i></p>
                    <p> <span class="count">99.99</span><span class="sup">% </span></p>
                    <h2>Availability</h2>
                </div>
                <div class="col-sm-6 col-md-3 column">
                    <p><i class="icon-user" aria-hidden="true"></i></p>
                    <p> <span class="count">1500</span></p>
                    <h2>Users</h2>
                </div>
            </div>
        </div>
    </section>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Animated-numbers-section.js"></script>
</body>

</html>