<?php


session_start();
$Name=$Mobile=$Email=$PWD=$Address="";
include('assets/Database/DBMySql.php'); $db=new DBMySql;
include('assets/phpscript/FormatedOutput.php');
$City="";if(isset($_GET["City"])) $City=$_GET["City"];
$CityList=SelectOptionsFormArray(array("Select City","Delhi","Dehradun","Lucknow"),$City);

$Parkings=$db->GetResult("select * from parkings where City='".$City."'");


?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Smart Parking</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,700">
    <link rel="stylesheet" href="assets/fonts/simple-line-icons.min.css">
    <link rel="stylesheet" href="assets/css/Animated-numbers-section.css">
    <link rel="stylesheet" href="assets/css/Feature-Section-MD.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="font-family: Roboto, sans-serif;">
    <?php include ("menu.php");?>
    <div class="container" style="margin-top: 21px;">
        <div class="card border rounded shadow-sm">
            <div class="card-body">
                <form>
                    <div class="form-row">
                        <div class="col-4">
                        <select class="form-control" name="City">
                        <?php echo $CityList;?>
                        </select></div>
                        <div class="col text-right">
                        <button class="btn btn-secondary" type="submit">Search</button></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <hr>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><strong>Search Result</strong></h5>
            </div>
            <div class="table-responsive">
                <table class="table table-striped">
                <thead>
               <tr>
                   <th>Sn.</th>
               <th>Parking Name</th>
                   <th>Address</th>
                   <th>Charges</th>
                   <th>TotalSlots</th>
               </tr>
                </thead>
                    <tbody>
                        <?php $n=1;
                              if($Parkings) while($row=$Parkings->fetch_assoc()){?>
                        <tr>
                            <td style="width: 39px;"><?php echo $n++;?></td>
                            <td>
                                <a href="booking.php?PID=<?php echo $row["PID"];?>">
                                    <?php echo $row["ParkingName"];?>
                                </a>
                            </td>
                            <td>
                                <?php echo $row["Address"];?>
                            </td>
                            <td><?php echo $row["Charge"];?></td>
                            <td>
                                <?php echo $row["TotalSlots"];?>
                            </td>
                        </tr>
                        <?php } ?>
                        
                      
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Animated-numbers-section.js"></script>
</body>

</html>