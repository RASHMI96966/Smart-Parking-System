<?php


session_start();
$Name=$Mobile=$Email=$PWD=$Address=$City ="";
include('assets/Database/DBMySql.php'); $db=new DBMySql;
include('assets/phpscript/FormatedOutput.php');
$Mobile="";if(isset($_GET["Mobile"])) $Mobile=$_GET["Mobile"];
$CityList=SelectOptionsFormArray(array("Delhi","Dehradun","Lucknow"),$City);

$Bookings=$db->GetResult("SELECT b.*,p.ParkingName,p.Charge,p.City FROM `bookings` b,`parkings` p WHERE b.`PID`=p.`PID` AND Mobile ='".$Mobile."' order by BookingDate DESC limit 0,20");


?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Smart Parking</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,700">
    <link rel="stylesheet" href="assets/fonts/simple-line-icons.min.css">
    <link rel="stylesheet" href="assets/css/Animated-numbers-section.css">
    <link rel="stylesheet" href="assets/css/Feature-Section-MD.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="font-family: Roboto, sans-serif;">
    <?php include ("menu.php");?>
    <div class="container" style="margin-top: 21px;">
        <div class="card border rounded shadow-sm">
            <div class="card-body">
                <form>
                    <div class="form-row">
                        <div class="col text-right">
                            
                            
                            <div class="input-group">
                                <div class="input-group-prepend"><span class="input-group-text">Enter Booking Mobile Number&nbsp;</span></div>
                                <input class="form-control" value="<?php echo $Mobile;?>" type="text" placeholder="10 digit Mobile Number" name="Mobile" required="" maxlength="10" />
                                <div class="input-group-append"><button class="btn btn-primary" type="submit">Search</button></div>
                            </div>
                            
                                
                            
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <hr>
    <div class="container">
        <div class="card rounded shadow-sm">
            <div class="card-header text-white bg-info">
                <h5 class="mb-0">
                    <strong>Search Result</strong>
                </h5>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Sn.</th>
                            <th>Parking Name</th>
                            <th>Slot</th>
                            <th>City</th>
                            <th>Date</th>
                            <th style="width: 104px;">Charges /-</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $n=1;
                              if($Bookings) while($row=$Bookings->fetch_assoc()){?>
                        <tr>
                            <td style="width: 39px;">
                                <?php echo $n++;?>
                            </td>
                            <td>

                                <?php echo $row["ParkingName"];?>

                            </td>
                            <td>
                                <?php echo $row["SlotNumber"];?>
                            </td>

                            <td>
                                <?php echo $row["City"];?>

                                <td>
                                    <?php echo $row["BookingDate"];?>
                                </td>
                                <td>
                                    <?php echo $row["Charge"];?>
                                </td>
                        </tr>
                        <?php } else if($Mobile!=""){?>
                                  <tr><td><h3>No records to display</h3></td></tr>
                        <?php } ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Animated-numbers-section.js"></script>
</body>

</html>