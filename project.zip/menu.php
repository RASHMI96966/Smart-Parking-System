
<nav class="navbar navbar-dark navbar-expand-md bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Smart Parking</a>
        <button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse"
            id="navcol-1">
            <ul class="nav navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="search.php">Search</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="mybookings.php">My Bookings</a>
                </li>
            </ul>
        </div>
    </div>
</nav>