<?php


session_start();
$ParkingName=$Charge=$City=$TotalSlots=$Address=$SlotNumber=$VehicleNumber=$err=$Result=$Mobile=$CustomerName="";
$BookingDate = date("Y-m-d");
include('assets/Database/DBMySql.php'); $db=new DBMySql;
include('assets/phpscript/FormatedOutput.php');
$PID="0";
if(isset($_GET["PID"])) $PID=$_GET["PID"];

if(isset($_GET["BookNow"]))
{
    $PID=$_GET["PID"];
    $VehicleNumber=$_GET["VehicleNumber"];

    $BookingDate =$_GET["BookingDate"];
    $CustomerName=$_GET["CustomerName"];
    $Mobile=$_GET["Mobile"];
    $SlotNumber=$_GET["SlotNumber"];

    $check=$db->ScalerQuery("Select Count(*) from bookings where SlotNumber=".$SlotNumber." and BookingDate='".$BookingDate."' and PID=".$PID);

    if ($check!="0")
    {
        $Result="Conflict";
    }
    else{
        $sql="INSERT INTO `bookings` (`BookingDate`,`CustomerName`,`VehicleNumber`,`Mobile`,`PID`,`SlotNumber` ) VALUES('".$BookingDate."','".$CustomerName."','".$VehicleNumber."','".$Mobile."',".$PID.",".$SlotNumber.")";
        if($db->NonQuery($sql))
        {
            $Result="Success";
        }

    }


}







$Parking=$db->GetSingleRow("select * from parkings where PID=".$PID);
if($Parking){

    $PID=$Parking["PID"];
    $ParkingName=$Parking["ParkingName"];
    $Charge=$Parking["Charge"];
    $City=$Parking["City"];
    $Address=$Parking["Address"];
    $TotalSlots=$Parking["TotalSlots"];

}
$arr = [];
for ($i = 1; $i <= $TotalSlots; $i++)	array_push($arr,$i);
$SlotList = SelectOptionsFormArray($arr,$SlotNumber);

?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Smart Parking</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,700">
    <link rel="stylesheet" href="assets/fonts/simple-line-icons.min.css">
    <link rel="stylesheet" href="assets/css/Animated-numbers-section.css">
    <link rel="stylesheet" href="assets/css/Feature-Section-MD.css">
    <link rel="stylesheet" href="assets/css/Hero-Technology.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="font-family: Roboto, sans-serif;">
    <?php include ("menu.php");?>
    <div class="container" style="margin-top: 20px;">
        <div class="row">
            <div class="col-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h4 class="card-title"><strong>Book Slot Now</strong></h4>
                        <form>
                        <input hidden name="PID" value="<?php echo $PID ?>"/>
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <td>Select Date</td>
                                            <td><input class="form-control" type="date" name="BookingDate" required value="<?php echo $BookingDate ;?>"></td>
                                        </tr>
                                        <tr>
                                            <td>Select Slot</td>
                                            <td><select class="form-control" name="SlotNumber" required="">
                                            <?php echo $SlotList; ?>
                                            </select></td>                                        </tr>
                                        <tr>
                                            <td>Name</td>
                                            <td>
<input class="form-control" type="text" placeholder="Enter Name" name="CustomerName" value="<?php echo $CustomerName ;?>" required="" /></td>
                                        </tr>
                                        <tr>
                                            <td>Vehicle No.</td>
                                            <td>
                                                <input class="form-control" type="text" placeholder="Enter Vehicle Number" value="<?php echo $VehicleNumber ;?>" pattern="[A-Z]{2}[0-9]{2}[A-Z]{2}[0-9]{4}" name="VehicleNumber" required maxlength="10" /></td>
                                        </tr>
                                        <tr>
                                            <td>Mobile</td>
                                            <td>
<input class="form-control" type="text" placeholder="Mobile Number" value="<?php echo $Mobile ;?>" name="Mobile" pattern="[6789][0-9]{9}" required maxlength="10" /></td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td class="text-right"><button class="btn btn-primary" name="BookNow" type="submit">Book Now</button></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <?php
                            if($Result =="Conflict") PrintAlert("Slot is Already Booked","Danger");
                            if($Result =="Success") PrintAlert("Booking Done Successfully","Success");

                            ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h4 class="card-title"><strong>Parking Description</strong></h4>
                        <form>
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <td>Name</td>
                                            <td><?php echo $ParkingName;?></td>
                                        </tr>
                                        <tr>
                                            <td>City</td>
                                            <td><?php echo $City;?></td>
                                        </tr>
                                        <tr>
                                            <td>Address</td>
                                            <td><?php echo $Address;?></td>
                                        </tr>
                                        <tr>
                                            <td>Charges</td>
                                            <td><?php echo $Charge;?></td>
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Animated-numbers-section.js"></script>
</body>

</html>